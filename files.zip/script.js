// Default budget allocation percentages
const defaultBudget = {
    'Venue & Catering': 30,
    'Decorations & Flowers': 15,
    'Photography & Videography': 12,
    'Music & Entertainment': 10,
    'Attire': 8,
    'Ceremony': 5,
    'Rings & Invitations': 10,
    'Honeymoon': 10
};

let currentBudgetAllocations = { ...defaultBudget };
let totalBudget = 0;
let guestCount = 0;

function calculateBudget() {
    const weddingDateInput = document.getElementById('wedding-date').value;
    guestCount = parseInt(document.getElementById('guest-count').value);
    totalBudget = parseFloat(document.getElementById('total-budget').value);

    // Validation
    if (!weddingDateInput || !guestCount || !totalBudget) {
        alert('Please fill in all fields');
        return;
    }

    if (guestCount <= 0 || totalBudget <= 0) {
        alert('Guest count and budget must be greater than 0');
        return;
    }

    // Calculate days until wedding
    const weddingDate = new Date(weddingDateInput);
    const today = new Date();
    const daysUntil = Math.ceil((weddingDate - today) / (1000 * 60 * 60 * 24));

    // Update summary
    const costPerGuest = (totalBudget / guestCount).toFixed(2);
    document.getElementById('days-until').textContent = daysUntil >= 0 ? daysUntil : '0';
    document.getElementById('cost-per-guest').textContent = `$${costPerGuest}`;
    document.getElementById('total-budget-display').textContent = `$${totalBudget.toLocaleString()}`;

    // Show sections
    document.getElementById('summary-section').style.display = 'block';
    document.getElementById('breakdown-section').style.display = 'block';
    document.getElementById('custom-section').style.display = 'block';
    document.getElementById('action-section').style.display = 'block';

    // Update breakdown
    updateBreakdown();
    populateCustomForm();
}

function updateBreakdown() {
    const breakdownContainer = document.getElementById('breakdown-categories');
    breakdownContainer.innerHTML = '';

    let total = 0;
    for (const [category, percentage] of Object.entries(currentBudgetAllocations)) {
        const amount = (totalBudget * percentage) / 100;
        total += percentage;

        const budgetItem = document.createElement('div');
        budgetItem.className = 'budget-item';
        budgetItem.innerHTML = `
            <div class="item-header">
                <span class="category-name">${category}</span>
                <span class="percentage">${percentage}%</span>
            </div>
            <div class="budget-bar">
                <div class="budget-fill" style="width: ${percentage}%"></div>
            </div>
            <div class="amount">$${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
        `;
        breakdownContainer.appendChild(budgetItem);
    }

    // Warn if total doesn't equal 100%
    if (Math.abs(total - 100) > 0.01) {
        const warning = document.createElement('div');
        warning.style.cssText = 'background-color: #fff3cd; padding: 15px; border-radius: 8px; margin-top: 20px; color: #856404; border-left: 5px solid #ffc107;';
        warning.innerHTML = `⚠️ Total allocation: ${total.toFixed(1)}% (should be 100%)`;
        breakdownContainer.appendChild(warning);
    }
}

function populateCustomForm() {
    const customContainer = document.getElementById('custom-categories');
    customContainer.innerHTML = '';

    for (const [category, percentage] of Object.entries(currentBudgetAllocations)) {
        const customItem = document.createElement('div');
        customItem.className = 'custom-item';
        customItem.innerHTML = `
            <label for="${category}">${category}</label>
            <input type="number" id="${category}" min="0" max="100" value="${percentage}" step="0.1">
        `;
        customContainer.appendChild(customItem);
    }
}

function updateCustomBudget() {
    let totalPercentage = 0;
    for (const category of Object.keys(currentBudgetAllocations)) {
        const input = document.getElementById(category);
        const value = parseFloat(input.value);

        if (isNaN(value) || value < 0) {
            alert(`Invalid value for ${category}`);
            return;
        }

        currentBudgetAllocations[category] = value;
        totalPercentage += value;
    }

    if (Math.abs(totalPercentage - 100) > 0.01) {
        const difference = (100 - totalPercentage).toFixed(1);
        alert(`⚠️ Total allocation is ${totalPercentage.toFixed(1)}%. It should be 100%.\nDifference: ${difference}%`);
    }

    updateBreakdown();
}

function exportBudget() {
    let text = '═══════════════════════════════════════════\n';
    text += '        💐 WEDULATOR - WEDDING BUDGET 💐\n';
    text += '═══════════════════════════════════════════\n\n';

    const weddingDateInput = document.getElementById('wedding-date').value;
    text += `Wedding Date: ${new Date(weddingDateInput).toLocaleDateString()}\n`;
    text += `Guest Count: ${guestCount}\n`;
    text += `Total Budget: $${totalBudget.toLocaleString()}\n`;
    text += `Cost Per Guest: $${(totalBudget / guestCount).toLocaleString('en-US', { minimumFractionDigits: 2 })}\n`;
    text += '\n' + '─'.repeat(45) + '\n';
    text += 'BUDGET BREAKDOWN:\n';
    text += '─'.repeat(45) + '\n\n';

    for (const [category, percentage] of Object.entries(currentBudgetAllocations)) {
        const amount = (totalBudget * percentage) / 100;
        text += `${category.padEnd(30)} ${String(percentage).padStart(6)}% - $${String(amount.toFixed(2)).padStart(10)}\n`;
    }

    text += '\n' + '═'.repeat(45) + '\n';
    text += '💕 Plan your perfect day with Wedulator! 💕\n';
    text += '═'.repeat(45) + '\n';

    // Download as text file
    const blob = new Blob([text], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `wedding-budget-${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
}

function resetCalculator() {
    if (confirm('Are you sure you want to reset the calculator?')) {
        document.getElementById('input-section').reset();
        document.getElementById('summary-section').style.display = 'none';
        document.getElementById('breakdown-section').style.display = 'none';
        document.getElementById('custom-section').style.display = 'none';
        document.getElementById('action-section').style.display = 'none';
        currentBudgetAllocations = { ...defaultBudget };
        totalBudget = 0;
        guestCount = 0;
    }
}